﻿using Microsoft.QueryStringDotNET;
using NotificationsExtensions.Toasts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using Windows.ApplicationModel.Background;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Core;
using Windows.UI.Notifications;
using Windows.UI.Xaml;
using winsdkfb;
using winsdkfb.Graph;

namespace BackgroundTaskComponent
{
    public sealed class ToastNotificationBackgroundTask : IBackgroundTask
    {
               
        public async void Run(IBackgroundTaskInstance taskInstance)
        {
            var cost = BackgroundWorkCost.CurrentBackgroundWorkCost;

            // Get a deferral since we're executing async code
            var deferral = taskInstance.GetDeferral();

            try
            {
                // If it's a toast notification action
                if (taskInstance.TriggerDetails is ToastNotificationActionTriggerDetail)
                {
                    // Get the toast activation details
                    var details = taskInstance.TriggerDetails as ToastNotificationActionTriggerDetail;

                    // Deserialize the arguments received from the toast activation
                    QueryString args = QueryString.Parse(details.Argument);

                    // Depending on what action was taken...
                    switch (args["action"])
                    {
                        // User clicked the reply button (doing a quick reply)
                        case "reserve":
                            await HandleReserve(details, args);
                            break;

                        // User clicked the share button
                        case "spots":
                            await HandleSpots(details,args);
                            break;

                         case "fb":
                            await HandleFB(details, args);
                            break;

                        default: return;
                            //throw new NotImplementedException();
                    }
                }

                // Otherwise handle other background activations
                else
                    throw new NotImplementedException();
            }

            finally
            {
                // And finally release the deferral since we're done
                deferral.Complete();
            }
        }

        private async Task HandleReserve(ToastNotificationActionTriggerDetail details, QueryString args)
        {
           
            //Get RSVP URL
            string rsvpURL = (string)args["url"];

           
            if (rsvpURL.ToLower().StartsWith("http")==false)
                rsvpURL = "http://" + rsvpURL;

            // The URI to launch
            var uriBing = new Uri(rsvpURL);

            // Launch the URI
            var success = await Windows.System.Launcher.LaunchUriAsync(uriBing);

            if (success)
            {
                // URI launched
            }
            else
            {
                // URI launch failed
            }

           

        }

        private async Task HandleSpots(ToastNotificationActionTriggerDetail details, QueryString args)
        {

        }

        private async Task HandleFB(ToastNotificationActionTriggerDetail details, QueryString args)
        {
            //Get RSVP URL
            string rsvpURL = (string)args["FBUrl"];


            if (rsvpURL.ToLower().StartsWith("http") == false)
                rsvpURL = "http://" + rsvpURL;

            // The URI to launch
            var uriBing = new Uri(rsvpURL);

            // Launch the URI
            var success = await Windows.System.Launcher.LaunchUriAsync(uriBing);

            if (success)
            {
                // URI launched
            }
            else
            {
                // URI launch failed
            }

        }

        //private async Task HandleShare(ToastNotificationActionTriggerDetail details, QueryString args)
        //{

        //    await Window.Current.Dispatcher.RunAsync(CoreDispatcherPriority.Normal, async() =>
        //    {
        //        //Share to Facebook
        //        FBSession sess = FBSession.ActiveSession;

        //    sess.FBAppId = "240580952944958";
        //    sess.WinAppId = "s-1-15-2-3199583901-23291003-159307449-3549130627-744368325-712392767-4176065968";

        //    List<String> permissionList = new List<String>();
        //    permissionList.Add("public_profile");
        //    permissionList.Add("publish_actions");
        //    permissionList.Add("user_photos");

        //    try
        //    {
        //        FBPermissions permissions = new FBPermissions(permissionList);

        //        // Login to Facebook
        //        FBResult result = await sess.LoginAsync(permissions);

        //        if (result.Succeeded)
        //        {
        //            // Set caption, link and description parameters
        //            PropertySet parameters = new PropertySet();
        //            parameters.Add("title", "Microsoft");
        //            parameters.Add("link", "https://www.microsoft.com/en-us/default.aspx");
        //            parameters.Add("description", "Microsoft home page");
        //            // Display feed dialog
        //            FBResult fbresult = await sess.ShowFeedDialogAsync(parameters);

        //        }
        //    } 
        //    catch(Exception ex)
        //    {

        //    }

        //    });



        //}


    }
}
