﻿using System;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.MobileServices;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using System.Linq;
using Windows.Security.Credentials;
using Windows.Networking.PushNotifications;
using Microsoft.WindowsAzure.Messaging;
using Windows.Security.Authentication.Web;
using winsdkfb;
using winsdkfb.Graph;
using System.Collections.Generic;
using Windows.Foundation.Collections;
using Newtonsoft.Json.Linq;


// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace App2
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {

        //Define the value to store user basic information to passing to next frame / page
        PropertySet userInfo = new PropertySet();

        public MainPage()
        {
            this.InitializeComponent();
        }

        private async System.Threading.Tasks.Task<bool> AuthenticateAsync()
        {
            string message;
            bool success = false;

            // This sample uses the Facebook provider.
            //var provider = MobileServiceAuthenticationProvider.Facebook;

            //// Use the PasswordVault to securely store and access credentials.
            //PasswordVault vault = new PasswordVault();
            //PasswordCredential credential = null;

            FBSession sess = FBSession.ActiveSession;

            //string SID = WebAuthenticationBroker.GetCurrentApplicationCallbackUri().ToString();

            sess.FBAppId = "240580952944958"; 
            sess.WinAppId = "s-1-15-2-3199583901-23291003-159307449-3549130627-744368325-712392767-4176065968" ;
            List<String> permissionList = new List<String>();
            permissionList.Add("public_profile");
            permissionList.Add("publish_actions");
           permissionList.Add("user_photos");
            


            // Specify that we want the First Name, Last Name and Locale that is connected to the user
            PropertySet parameters = new PropertySet();
            parameters.Add("fields", "locale,email");

            // Set Graph api path to get data about this user
            string path = "/me/";

            // Create the request to send to the Graph API, also specify the format we're expecting (In this case a json that can be parsed into FBUser)
            FBSingleValue sval = new FBSingleValue(path, parameters, new FBJsonClassFactory(FBUser.FromJson));

            FBPermissions permissions = new FBPermissions(permissionList);

            // Login to Facebook
            FBResult result = await sess.LoginAsync(permissions);

            if (result.Succeeded)
            {
                var currentUser = FBSession.ActiveSession.User;

                //Get the result with Graph API                
                FBResult fbResult = await sval.GetAsync();

                // Extract the FBUser with new data
                var extendedUser = ((FBUser)fbResult.Object);

                // Attach the newly fetched data to the current user
                currentUser.Email = extendedUser.Email;
                currentUser.Locale = extendedUser.Locale;

                userInfo.Add("ID", extendedUser.Id);
                userInfo.Add("Name", currentUser.Name);
                userInfo.Add("Email", extendedUser.Email);

                success = true;

            }
            else
            {
                //Unable to retrieve user information
                message = "Unable to retrieve Facebook user information";

                var dialogFB = new MessageDialog(message);
                dialogFB.Commands.Add(new UICommand("OK"));

                await dialogFB.ShowAsync();

                return success;
            }

            try
            {
                // Try to get an existing credential from the vault.
               // credential = vault.FindAllByResource(provider.ToString()).FirstOrDefault();

            }
            catch (Exception)
            {
                // When there is no matching resource an error occurs, which we ignore.
            }

            //if (credential != null)
            //{
            //    // Create a user from the stored credentials.
            //    user = new MobileServiceUser(credential.UserName);
            //    credential.RetrievePassword();
            //    user.MobileServiceAuthenticationToken = credential.Password;

            //    // Set the user from the stored credentials.
            //    App.MobileService.CurrentUser = user;

            //    // Consider adding a check to determine if the token is 
            //    // expired, as shown in this post: http://aka.ms/jww5vp.

            //    success = true;
            //    message = string.Format("Cached credentials for user - {0}", user.UserId);

            //}
            //else
            //{
            //    try
            //    {
            //        // Login with the identity provider.
            //        user = await App.MobileService.LoginAsync(provider);

            //        // Create and store the user credentials.
            //        credential = new PasswordCredential(provider.ToString(), user.UserId, user.MobileServiceAuthenticationToken);
            //        vault.Add(credential);

            //        success = true;
            //        message = string.Format("You are now logged in - {0}", user.UserId);
            //    }
            //    catch (MobileServiceInvalidOperationException)
            //    {
            //        message = "You must log in. Login Required";

            //        var dialog = new MessageDialog(message);
            //        dialog.Commands.Add(new UICommand("OK"));
            //        await dialog.ShowAsync();
            //    }
            //}


            return success;
        }

        private async void ButtonLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {


                // Login the user and then load data from the mobile app.
                if (await AuthenticateAsync())
                {

                    //await InitNotificationsAsync();

                    Frame rootFrame = Window.Current.Content as Frame;

                    // Do not repeat app initialization when the Window already has content,
                    // just ensure that the window is active
                    if (rootFrame == null)
                    {
                        rootFrame.Navigate(typeof(MainPage));
                    }

                   
                    rootFrame.Navigate(typeof(Subscriber), userInfo);

                    //await InitLocalStoreAsync(); //offline sync support.
                    // await RefreshTodoItems();

                    Window.Current.Content = rootFrame;

                    Window.Current.Activate();
                }
            }
            catch (MessagingException ex)
            {
                throw ex;
            }
        }

        private void cbxDis_Click(object sender, RoutedEventArgs e)
        {
            if (cbxDis.IsChecked == true)
            {
                ButtonLogin.IsEnabled = true;
            }
            else
                ButtonLogin.IsEnabled = false;
        }
    }
}
