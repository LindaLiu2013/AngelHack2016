﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Networking.PushNotifications;
using Microsoft.WindowsAzure.Messaging;
using Windows.UI.Popups;
using Windows.UI.Notifications;
using Windows.Storage;
using Newtonsoft.Json.Linq;
using Windows.System;

namespace App2
{
    public class Notifications
    {
        private NotificationHub hub;

        public Notifications(string hubName, string listenConnectionString)
        {
            hub = new NotificationHub(hubName, listenConnectionString);
                     
        }

        public async Task StoreCategoriesAndSubscribe(IEnumerable<string> categories)
        {
            ApplicationData.Current.LocalSettings.Values["categories"] = string.Join(",", categories);

            await SubscribeToCategories(categories);
        }

        public IEnumerable<string> RetrieveCategories()
        {
            var categories = (string)ApplicationData.Current.LocalSettings.Values["categories"];
            return categories != null ? categories.Split(',') : new string[0];
        }

        public async Task SubscribeToCategories(IEnumerable<string> categories = null)
        {
            var channel = await PushNotificationChannelManager.CreatePushNotificationChannelForApplicationAsync();

            

            if (categories == null)
            {
                categories = RetrieveCategories();
            }

            
            // Define two new tags as a JSON array.
            var body = new JArray();
            body.Add(categories);

           // body.Add("_UserId:" + App.MobileService.CurrentUser.UserId);

            //var currentTags = await App.MobileService.InvokeApiAsync("UpdateTags/" + App.MobileService.InstallationId, body);

            // Call the custom API '/api/updatetags/<installationid>' 
            // with the JArray of tags.
            //var t = await App.MobileService.InvokeApiAsync("UpdateTags/" + App.MobileService.InstallationId, body);
            //await App.MobileService.InvokeApiAsync("UpdateTags/Id", App.MobileService.InstallationId, body,);

            //MessageDialog dialog = new MessageDialog(t.ToString());
            //dialog.Commands.Add(new UICommand("OK"));
            //await dialog.ShowAsync();
                        

        }

    }
}
