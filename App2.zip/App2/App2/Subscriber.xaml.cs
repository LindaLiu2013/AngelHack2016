﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.Devices.Geolocation;
using System.Dynamic;
using System.Net.Http;
using Newtonsoft.Json;
using Windows.Data.Json;
using InteractiveToastExtensions;
using Windows.UI.Notifications;


// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace App2
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Subscriber : Page
    {

        private uint _desireAccuracyInMetersValue = 0;

        public Subscriber()
        {
            this.InitializeComponent();

            rootFrame = Window.Current.Content as Frame;

        }

        public static Frame rootFrame = null;

        private void rdoHeat_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void rdoQuite_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            if (rootFrame != null)
            {
                rootFrame.Navigate(typeof(MainPage));
            }

        }

        private async void SubscribeButton_Click(object sender, RoutedEventArgs e)
        {
            var accessStatus = await Geolocator.RequestAccessAsync();

            switch (accessStatus)
            {
                case GeolocationAccessStatus.Allowed:
                    

                    // If DesiredAccuracy or DesiredAccuracyInMeters are not set (or value is 0), DesiredAccuracy.Default is used.
                    Geolocator geolocator = new Geolocator { DesiredAccuracyInMeters = _desireAccuracyInMetersValue };
                                      

                    // Carry out the operation.
                    Geoposition pos = await geolocator.GetGeopositionAsync();

                    if (pos==null)
                    {
                        var msg = "Unable to retrieve user's location";
                        return;
                    }

                    var latitudeData = pos.Coordinate.Point.Position.Latitude.ToString();
                    var longitudeData = pos.Coordinate.Point.Position.Longitude.ToString();

                    Uri requestUri = new Uri("https://cryptic-meadow-28141.herokuapp.com/optusResponse?lat="+ latitudeData + "&lon="+ longitudeData); //replace your Url  
                    System.Net.Http.HttpClient client = new System.Net.Http.HttpClient();
                    System.Net.Http.HttpResponseMessage responseGet = await client.GetAsync(requestUri);
                    var response = await responseGet.Content.ReadAsStringAsync();

                    var toastTitle = string.Empty;
                    var toastBody = string.Empty;
                    var imgURL=string.Empty;
                    var actionURL = string.Empty;
                    

                    JsonArray root = JsonValue.Parse(response).GetArray();

                      string name= root.GetObjectAt(0).GetNamedString("Name");
                        toastTitle = name;

                        toastBody = root.GetObjectAt(0).GetNamedString("Distance");
                        
                        toastBody += " away from you in "+root.GetObjectAt(0).GetNamedString("Address");

                        toastBody+=". Current "+ root.GetObjectAt(0).GetNamedString("PromoDesc");

                        toastBody += ". Optus HeatIndex: " + root.GetObjectAt(0).GetNamedString("HeatIndex");

                        imgURL = root.GetObjectAt(0).GetNamedString("ImageURL");

                        actionURL= root.GetObjectAt(0).GetNamedString("url");

                    string fbURL = "https://m.me/myairchathelp/";

                        var notification = DeadpoolNotification(toastTitle, toastBody, imgURL, actionURL,fbURL);

                        ToastNotificationManager.CreateToastNotifier().Show(notification);
                  

                    
                        // The URI to launch
                       // var uriBing = new Uri("https://m.me/myairchathelp/");

                        // Launch the URI
                       // var success = await Windows.System.Launcher.LaunchUriAsync(uriBing);
                   

                    break;

                case GeolocationAccessStatus.Denied:
                   
                    break;

                case GeolocationAccessStatus.Unspecified:
                  
                    break;
            }
        }

        private static ToastNotification DeadpoolNotification(string msgTitle, string msgText, string imagePath, string actionURL, string fbURL)
        {
          
            var toast = new InteractiveToast();
            var visual = new Visual();
            visual.AddText(new Text(msgTitle)); 
            visual.AddText(new Text(msgText));  


            visual.AddImage(new VisualImage(imagePath)
            {
                ImagePlacement = ImagePlacement.Inline,
                Alt = "center"
            });


            visual.AddImage(new VisualImage(imagePath) 
            {
                ImagePlacement = ImagePlacement.AppLogoOverride,
                ImageCropping = ImageCropping.Circle
            });


            toast.SetVisual(visual);
                       

            toast.AddActionItem(new ToastAction("Reserve", "action=reserve&amp;url="+ actionURL)
            {
                
                ActivationType = ActivationType.Background
            });

            toast.AddActionItem(new ToastAction("More Spots", "action=spots&amp;")
            {
                ActivationType = ActivationType.Background
            });

            toast.AddActionItem(new ToastAction("Chat On FB", "action=fb&amp;FBUrl="+fbURL)
            {
                ActivationType = ActivationType.Background
            });

            // Arguments when the user taps body of toast
            string argsLaunch = $"action=viewConversation";


            toast.LaunchArgs = argsLaunch; 

            var notification = toast.GetNotification();
            notification.ExpirationTime = DateTime.Now.AddDays(1);
            notification.Tag = "1";

            return notification;
        }
    }
}
